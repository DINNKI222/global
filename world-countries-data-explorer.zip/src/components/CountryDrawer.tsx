import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Map, Users, Activity, DollarSign, BookOpen, Info, Ruler, ExternalLink, Globe2, Languages, ArrowUpRight, TrendingUp, HeartPulse, GraduationCap, Building2 } from 'lucide-react';
import { Country } from '../types';

interface Props {
  country: Country | null;
  onClose: () => void;
}

export function CountryDrawer({ country, onClose }: Props) {
  const formatNumber = (num: number) => new Intl.NumberFormat('es-ES').format(num);

  return (
    <AnimatePresence>
      {country && (
        <>
          {/* Full Screen Modal */}
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-50 bg-slate-50 overflow-y-auto"
          >
            {/* Background Decorative Shapes (Drawings/Figures) */}
            <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
              <div className="absolute -top-[20%] -right-[10%] w-[50%] h-[50%] rounded-full bg-indigo-200/40 blur-3xl" />
              <div className="absolute top-[40%] -left-[10%] w-[40%] h-[40%] rounded-full bg-rose-200/40 blur-3xl" />
              <div className="absolute -bottom-[10%] right-[20%] w-[60%] h-[60%] rounded-full bg-emerald-200/30 blur-3xl" />
              
              {/* Decorative Icons as "drawings" */}
              <Globe2 className="absolute top-[10%] left-[5%] w-64 h-64 text-indigo-500/5 -rotate-12" />
              <Map className="absolute bottom-[20%] left-[10%] w-96 h-96 text-emerald-500/5 rotate-12" />
              <Building2 className="absolute top-[40%] right-[5%] w-72 h-72 text-rose-500/5 -rotate-6" />
            </div>

            {/* Header / Hero Section */}
            <div className="relative h-80 md:h-96 bg-slate-200 z-10 shadow-sm">
              <img
                src={country.flagUrl}
                alt={`Bandera de ${country.name}`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/40 to-transparent" />
              
              <button
                onClick={onClose}
                className="absolute top-6 right-6 p-3 bg-white/20 hover:bg-white/40 text-white rounded-full backdrop-blur-md transition-all border border-white/30 shadow-lg z-20"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="absolute bottom-0 left-0 right-0 p-8 md:p-12 max-w-7xl mx-auto w-full">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <span className="px-4 py-1.5 bg-white/20 text-white border border-white/30 text-sm font-bold uppercase tracking-wider rounded-full mb-4 inline-block backdrop-blur-md shadow-sm">
                    {country.continent}
                  </span>
                  <h2 className="text-5xl md:text-7xl font-display font-bold text-white leading-tight drop-shadow-xl">
                    {country.name}
                  </h2>
                </motion.div>
              </div>
            </div>

            {/* Content Container */}
            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* Left Column: Key Stats */}
                <div className="lg:col-span-2 space-y-8">
                  
                  {/* Prominent Population Card */}
                  <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl p-8 text-white shadow-xl shadow-blue-500/20 relative overflow-hidden">
                    <div className="absolute -right-10 -top-10 opacity-20">
                      <Users className="w-64 h-64" />
                    </div>
                    <div className="relative z-10">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                          <Users className="w-8 h-8 text-white" />
                        </div>
                        <h3 className="text-lg font-bold uppercase tracking-widest text-blue-100">Población Total</h3>
                      </div>
                      <p className="text-6xl md:text-7xl font-display font-bold drop-shadow-md">
                        {formatNumber(country.population)}
                      </p>
                      <p className="mt-4 text-blue-100 font-medium text-lg">
                        Habitantes registrados en {country.name}
                      </p>
                    </div>
                  </div>

                  {/* Other Stats Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                      <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:opacity-10 transition-opacity">
                        <Map className="w-32 h-32" />
                      </div>
                      <div className="flex items-center gap-2 text-emerald-500 mb-3 relative z-10">
                        <div className="p-2 bg-emerald-50 rounded-lg"><Map className="w-5 h-5" /></div>
                      </div>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1 relative z-10">Área (km²)</span>
                      <p className="text-3xl font-display font-bold text-slate-800 relative z-10">{formatNumber(country.area)}</p>
                    </div>
                    
                    <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                      <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:opacity-10 transition-opacity">
                        <HeartPulse className="w-32 h-32" />
                      </div>
                      <div className="flex items-center gap-2 text-rose-500 mb-3 relative z-10">
                        <div className="p-2 bg-rose-50 rounded-lg"><Activity className="w-5 h-5" /></div>
                      </div>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1 relative z-10">Esp. Vida</span>
                      <p className="text-3xl font-display font-bold text-slate-800 relative z-10">{country.lifeExpectancy} <span className="text-sm font-sans text-slate-500 font-medium">años</span></p>
                    </div>
                    
                    <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                      <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:opacity-10 transition-opacity">
                        <TrendingUp className="w-32 h-32" />
                      </div>
                      <div className="flex items-center gap-2 text-amber-500 mb-3 relative z-10">
                        <div className="p-2 bg-amber-50 rounded-lg"><DollarSign className="w-5 h-5" /></div>
                      </div>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1 relative z-10">PIB per cápita</span>
                      <p className="text-3xl font-display font-bold text-slate-800 relative z-10">${formatNumber(country.gdpPerCapita)}</p>
                    </div>
                  </div>

                  {/* Cultural Facts */}
                  <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-100 p-8 rounded-3xl relative overflow-hidden shadow-sm">
                    <div className="absolute top-0 right-0 p-8 opacity-10">
                      <Globe2 className="w-48 h-48 text-indigo-900" />
                    </div>
                    <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-wider mb-4 flex items-center gap-2 relative z-10">
                      <Info className="w-5 h-5" />
                      Datos Culturales y Curiosidades
                    </h3>
                    <p className="text-slate-700 text-lg leading-relaxed relative z-10 font-medium">
                      {country.culturalFacts}
                    </p>
                  </div>

                  {/* Health & Education */}
                  <div className="bg-white border border-slate-200 p-8 rounded-3xl shadow-sm relative overflow-hidden">
                    <div className="absolute -right-10 -bottom-10 opacity-5">
                      <GraduationCap className="w-64 h-64 text-emerald-900" />
                    </div>
                    <h3 className="text-sm font-bold text-emerald-600 uppercase tracking-wider mb-4 flex items-center gap-2 relative z-10">
                      <BookOpen className="w-5 h-5" />
                      Salud y Educación
                    </h3>
                    <p className="text-slate-600 text-base leading-relaxed relative z-10">
                      {country.healthEducationLink}
                    </p>
                  </div>

                </div>

                {/* Right Column: Sidebar Info */}
                <div className="space-y-6">
                  
                  {/* Language */}
                  <div className="bg-white border border-slate-200 p-6 rounded-3xl shadow-sm relative overflow-hidden">
                    <div className="absolute -right-4 -bottom-4 opacity-5">
                      <Languages className="w-32 h-32 text-sky-900" />
                    </div>
                    <div className="flex items-center gap-4 mb-2 relative z-10">
                      <div className="p-3 bg-sky-100 text-sky-600 rounded-2xl">
                        <Languages className="w-8 h-8" />
                      </div>
                      <div>
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Idioma Oficial</h3>
                        <p className="text-2xl font-bold text-slate-800">{country.language}</p>
                      </div>
                    </div>
                  </div>

                  {/* Additional Info */}
                  <div className="bg-white border border-slate-200 p-6 rounded-3xl shadow-sm">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                      <Info className="w-4 h-4 text-slate-400" />
                      Información General
                    </h3>
                    <div className="space-y-3">
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Capital</span>
                        <span className="font-bold text-slate-800 text-lg">{country.capital || 'Desconocida'}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Subregión</span>
                        <span className="font-bold text-slate-800 text-lg">{country.subregion || 'Desconocida'}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Moneda(s)</span>
                        <span className="font-bold text-slate-800 text-lg">{country.currencies || 'Desconocida'}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Zona(s) Horaria(s)</span>
                        <span className="font-bold text-slate-800 text-sm">{country.timezones || 'Desconocida'}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Fronteras</span>
                        <span className="font-bold text-slate-800 text-sm">{country.borders || 'Ninguna'}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Gentilicio</span>
                        <span className="font-bold text-slate-800 text-sm">{country.demonym || 'Desconocido'}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Prefijo Telefónico</span>
                        <span className="font-bold text-slate-800 text-sm">{country.callingCode || 'Desconocido'}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Dominio Web</span>
                        <span className="font-bold text-slate-800 text-sm">{country.tld || 'Desconocido'}</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col">
                        <span className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Conducción</span>
                        <span className="font-bold text-slate-800 text-sm">{country.drivingSide || 'Desconocido'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Heights */}
                  <div className="bg-white border border-slate-200 p-6 rounded-3xl shadow-sm">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                      <Ruler className="w-4 h-4 text-slate-400" />
                      Estatura Promedio
                    </h3>
                    <div className="space-y-3">
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex items-center justify-between">
                        <span className="text-sm text-slate-600 font-medium">Hombres</span>
                        <span className="font-mono text-slate-800 font-bold text-xl">{country.heightMale} cm</span>
                      </div>
                      <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex items-center justify-between">
                        <span className="text-sm text-slate-600 font-medium">Mujeres</span>
                        <span className="font-mono text-slate-800 font-bold text-xl">{country.heightFemale} cm</span>
                      </div>
                    </div>
                  </div>

                  {/* Map Link */}
                  {country.mapUrl && (
                    <a 
                      href={country.mapUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="group flex items-center justify-between p-6 bg-slate-800 hover:bg-indigo-600 text-white rounded-3xl transition-all shadow-lg hover:shadow-indigo-500/25"
                    >
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-white/10 rounded-2xl group-hover:bg-white/20 transition-colors">
                          <Map className="w-8 h-8" />
                        </div>
                        <span className="font-bold text-xl">Ver en Mapa</span>
                      </div>
                      <ArrowUpRight className="w-8 h-8 opacity-50 group-hover:opacity-100 transition-opacity group-hover:translate-x-1 group-hover:-translate-y-1" />
                    </a>
                  )}

                  {/* Sources */}
                  <div className="bg-slate-100 p-6 rounded-3xl border border-slate-200">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Fuentes de Datos</h3>
                    <p className="text-slate-500 text-sm italic">
                      {country.sources}
                    </p>
                  </div>

                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
