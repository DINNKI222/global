import React, { useState, useMemo, useEffect } from 'react';
import { Search, Download, Copy, Globe, Activity, DollarSign, Users, Map, Loader2, ChevronRight, Filter } from 'lucide-react';
import { Country } from './types';
import { fetchAllCountries } from './utils/dataFetcher';
import { CountryDrawer } from './components/CountryDrawer';

const CONTINENTS = ['Todos', 'África', 'América', 'Asia', 'Europa', 'Oceanía'];

export default function App() {
  const [countries, setCountries] = useState<Country[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedContinent, setSelectedContinent] = useState('Todos');
  const [copied, setCopied] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      const data = await fetchAllCountries();
      setCountries(data);
      setIsLoading(false);
    };
    loadData();
  }, []);

  const filteredCountries = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return countries.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(term) ||
                            c.continent.toLowerCase().includes(term) ||
                            c.language.toLowerCase().includes(term);
      const matchesContinent = selectedContinent === 'Todos' || c.continent.includes(selectedContinent);
      return matchesSearch && matchesContinent;
    });
  }, [searchTerm, selectedContinent, countries]);

  const generateCSV = (data: Country[]) => {
    const headers = [
      "País", "Continente", "Población", "Área (km2)", "Estatura Hombres (cm)", "Estatura Mujeres (cm)",
      "Esperanza de Vida (años)", "Idioma Oficial", "PIB per cápita (USD)", "Capital", "Subregión",
      "Moneda", "Zonas Horarias", "Fronteras", "Gentilicio", "Prefijo Telefónico", "Dominio Web",
      "Conducción", "Datos Culturales", "Relación Salud/Educación", "Fuentes"
    ];
    
    const escapeCSV = (str: string | number | undefined) => {
      if (str === undefined || str === null) return '';
      const stringified = String(str);
      if (stringified.includes(',') || stringified.includes('"') || stringified.includes('\n')) {
        return `"${stringified.replace(/"/g, '""')}"`;
      }
      return stringified;
    };

    const rows = data.map(c => [
      c.name, c.continent, c.population, c.area, c.heightMale, c.heightFemale,
      c.lifeExpectancy, c.language, c.gdpPerCapita, c.capital, c.subregion,
      c.currencies, c.timezones, c.borders, c.demonym, c.callingCode, c.tld,
      c.drivingSide, c.culturalFacts, c.healthEducationLink, c.sources
    ].map(escapeCSV).join(','));

    return [headers.join(','), ...rows].join('\n');
  };

  const handleDownloadCSV = () => {
    const csv = generateCSV(filteredCountries);
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'datos_paises_mundo.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyClipboard = async () => {
    const csv = generateCSV(filteredCountries);
    try {
      await navigator.clipboard.writeText(csv);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('es-ES').format(num);
  };

  return (
    <div className="min-h-screen font-sans selection:bg-indigo-500/30 selection:text-indigo-900 pb-12">
      {/* Header */}
      <header className="sticky top-0 z-30 glass-panel border-b border-slate-200 shadow-sm">
        <div className="max-w-[100rem] mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-xl shadow-lg shadow-indigo-500/20">
                <Globe className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                  Explorador Global
                </h1>
                <p className="text-sm text-slate-500 font-medium">Descubre el mundo en datos</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="relative w-full md:w-72">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2.5 border border-slate-200 rounded-xl leading-5 bg-white/50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all shadow-sm"
                  placeholder="Buscar país, idioma..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              
              <button
                onClick={handleCopyClipboard}
                disabled={isLoading || filteredCountries.length === 0}
                className="inline-flex items-center px-3 py-2.5 border border-slate-200 shadow-sm text-sm font-medium rounded-xl text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all disabled:opacity-50"
                title="Copiar CSV al portapapeles"
              >
                {copied ? <span className="text-emerald-600 font-medium">¡Copiado!</span> : <Copy className="h-4 w-4" />}
              </button>
              
              <button
                onClick={handleDownloadCSV}
                disabled={isLoading || filteredCountries.length === 0}
                className="inline-flex items-center px-4 py-2.5 border border-transparent shadow-lg shadow-indigo-500/20 text-sm font-medium rounded-xl text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all disabled:opacity-50"
              >
                <Download className="h-4 w-4 mr-2" />
                Exportar CSV
              </button>
            </div>
          </div>
          
          {/* Continent Filters */}
          <div className="mt-5 flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <div className="flex items-center gap-2 text-slate-500 mr-2">
              <Filter className="w-4 h-4" />
              <span className="text-sm font-medium">Filtros:</span>
            </div>
            {CONTINENTS.map(continent => (
              <button
                key={continent}
                onClick={() => setSelectedContinent(continent)}
                className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  selectedContinent === continent
                    ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/25 border border-indigo-500'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 shadow-sm'
                }`}
              >
                {continent}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-[100rem] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Stats Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-10">
          <div className="glass-card rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                <Globe className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Países</h3>
            </div>
            <p className="text-3xl font-display font-bold text-slate-900">{isLoading ? '-' : filteredCountries.length}</p>
          </div>
          <div className="glass-card rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Población Total</h3>
            </div>
            <p className="text-3xl font-display font-bold text-slate-900">
              {isLoading ? '-' : formatNumber(filteredCountries.reduce((acc, c) => acc + c.population, 0))}
            </p>
          </div>
          <div className="glass-card rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-amber-100 text-amber-600 rounded-lg">
                <Map className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Área Total (km²)</h3>
            </div>
            <p className="text-3xl font-display font-bold text-slate-900">
              {isLoading ? '-' : formatNumber(filteredCountries.reduce((acc, c) => acc + c.area, 0))}
            </p>
          </div>
          <div className="glass-card rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-rose-100 text-rose-600 rounded-lg">
                <Activity className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Prom. Esp. Vida</h3>
            </div>
            <p className="text-3xl font-display font-bold text-slate-900">
              {isLoading || filteredCountries.length === 0
                ? '-'
                : (filteredCountries.reduce((acc, c) => acc + c.lifeExpectancy, 0) / filteredCountries.length).toFixed(1)} <span className="text-sm text-slate-500 font-sans font-medium">años</span>
            </p>
          </div>
          <div className="glass-card rounded-2xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-purple-100 text-purple-600 rounded-lg">
                <DollarSign className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Prom. PIB per cápita</h3>
            </div>
            <p className="text-3xl font-display font-bold text-slate-900">
              ${isLoading || filteredCountries.length === 0
                ? '-'
                : formatNumber(Math.round(filteredCountries.reduce((acc, c) => acc + c.gdpPerCapita, 0) / filteredCountries.length))}
            </p>
          </div>
        </div>

        {/* Grid of Cards */}
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-32 text-slate-500 glass-card rounded-3xl">
            <Loader2 className="w-10 h-10 animate-spin text-indigo-500 mb-4" />
            <p className="text-lg font-medium">Cargando el mundo...</p>
          </div>
        ) : filteredCountries.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
            {filteredCountries.map((country) => (
              <div 
                key={country.id}
                onClick={() => setSelectedCountry(country)}
                className="glass-card rounded-2xl overflow-hidden cursor-pointer group flex flex-col h-full bg-white/60"
              >
                {/* Card Header / Flag */}
                <div className="relative h-40 overflow-hidden bg-slate-100">
                  <img 
                    src={country.flagUrl} 
                    alt={`Bandera de ${country.name}`}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent opacity-90" />
                  <div className="absolute bottom-3 left-4 right-4 flex justify-between items-end">
                    <span className="px-2.5 py-1 bg-white/20 backdrop-blur-md border border-white/30 text-white text-xs font-medium rounded-full shadow-sm">
                      {country.continent}
                    </span>
                  </div>
                </div>
                
                {/* Card Body */}
                <div className="p-5 flex-1 flex flex-col">
                  <h3 className="text-xl font-display font-bold text-slate-900 mb-4 line-clamp-1 group-hover:text-indigo-600 transition-colors">
                    {country.name}
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-3 mt-auto">
                    <div className="bg-white/80 rounded-xl p-3 border border-slate-100 shadow-sm">
                      <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                        <Users className="w-3.5 h-3.5 text-blue-500" />
                        <span className="text-[10px] uppercase font-bold tracking-wider">Población</span>
                      </div>
                      <p className="text-sm font-mono font-semibold text-slate-700">{formatNumber(country.population)}</p>
                    </div>
                    <div className="bg-white/80 rounded-xl p-3 border border-slate-100 shadow-sm">
                      <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                        <Activity className="w-3.5 h-3.5 text-rose-500" />
                        <span className="text-[10px] uppercase font-bold tracking-wider">Esp. Vida</span>
                      </div>
                      <p className="text-sm font-mono font-semibold text-slate-700">{country.lifeExpectancy} <span className="text-xs text-slate-400 font-sans">a</span></p>
                    </div>
                    <div className="bg-white/80 rounded-xl p-3 border border-slate-100 shadow-sm">
                      <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
                        <span className="text-[10px] uppercase font-bold tracking-wider">PIB</span>
                      </div>
                      <p className="text-sm font-mono font-semibold text-slate-700">${formatNumber(country.gdpPerCapita)}</p>
                    </div>
                    <div className="bg-white/80 rounded-xl p-3 border border-slate-100 shadow-sm">
                      <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                        <Map className="w-3.5 h-3.5 text-amber-500" />
                        <span className="text-[10px] uppercase font-bold tracking-wider">Área</span>
                      </div>
                      <p className="text-sm font-mono font-semibold text-slate-700" title={`${formatNumber(country.area)} km²`}>
                        {formatNumber(country.area)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-32 text-slate-500 glass-card rounded-3xl">
            <Search className="w-12 h-12 mb-4 opacity-50" />
            <p className="text-lg font-medium">No se encontraron países que coincidan con la búsqueda.</p>
          </div>
        )}
      </main>

      {/* Drawer */}
      <CountryDrawer 
        country={selectedCountry} 
        onClose={() => setSelectedCountry(null)} 
      />
    </div>
  );
}