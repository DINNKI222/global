export interface Country {
  id: string;
  name: string;
  continent: string;
  population: number;
  area: number;
  heightMale: number;
  heightFemale: number;
  lifeExpectancy: number;
  language: string;
  gdpPerCapita: number;
  culturalFacts: string;
  healthEducationLink: string;
  sources: string;
  flagUrl: string;
  coatOfArmsUrl?: string;
  mapUrl?: string;
  capital?: string;
  subregion?: string;
  currencies?: string;
  timezones?: string;
  borders?: string;
  demonym?: string;
  drivingSide?: string;
  tld?: string;
  callingCode?: string;
}
